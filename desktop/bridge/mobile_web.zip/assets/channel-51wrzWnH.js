import{ai as o,aj as n}from"./mermaid.core-X3lu8Gb1.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
