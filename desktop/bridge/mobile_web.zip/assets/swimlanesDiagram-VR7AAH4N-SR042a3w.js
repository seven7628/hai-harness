import{c as r,s as e}from"./flowDiagram-HODETNUW-BdFHvk0Q.js";import{_ as a}from"./mermaid.core-X3lu8Gb1.js";import"./chunk-5VM5RSS4-nCGTQF7o.js";import"./chunk-XXDRQBXY-CMmu6sRb.js";import"./chunk-POPQ4Y6H-eJybf6pT.js";import"./chunk-F27PBJKO-DhkCPLUU.js";import"./channel-51wrzWnH.js";import"./mobile-DSLa2yE4.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
